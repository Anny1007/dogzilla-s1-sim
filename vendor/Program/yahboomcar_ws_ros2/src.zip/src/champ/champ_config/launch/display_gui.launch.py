# Author: Addison Sears-Collins
# Date: September 23, 2021
# Description: Load a URDF and world file into Gazebo.
# https://automaticaddison.com

import os
from ament_index_python.packages import get_package_prefix
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import xacro

def generate_launch_description():

  # Constants for paths to different files and folders
  gazebo_models_path = 'models'
  package_name = 'box_car_gazebo'
  robot_name_in_model = 'yahboomcar_XGO'
  #rviz_config_file_path = 'rviz2/XGO.rviz'
  #urdf_file_path = 'urdf/two_wheeled_robot_with_gazebo_plugins.urdf'
  #xacro_file_path = os.path.join(get_package_share_directory('box_car_description'), 'robot/XGO/', 'XGO.xacro')  
  #xacro_file_path = 'robot/XGO/XGO.xacro'
  world_file_path = 'worlds/box_bot_empty.world'
    
  # Pose where we want to spawn the robot
  spawn_x_val = str(0.0)
  spawn_y_val = str(0.0)
  spawn_z_val = str(0.4)
  spawn_roll_val = str(0)
  spawn_pitch_val = str(0.0)
  spawn_yaw_val = str(0.0)

  ############ You do not need to change anything below this line #############
  
  # Set the path to different files and folders.  
  pkg_gazebo_ros = FindPackageShare(package='gazebo_ros').find('gazebo_ros')   
  pkg_share = FindPackageShare(package=package_name).find(package_name)
  #default_urdf_model_path = os.path.join(pkg_share, urdf_file_path)
  #default_xacro_model_path = os.path.join(pkg_share, xacro_file_path)
  default_xacro_model_path = os.path.join(get_package_share_directory('box_car_description'), 'robot/XGO/', 'XGO.xacro') 
  default_rviz_config_path = os.path.join(get_package_share_directory('box_car_description'), 'rviz2/', 'XGO.rviz') 
  world_path = os.path.join(pkg_share, world_file_path)
  #world_path = [os.path.join(pkg_box_car_gazebo, 'worlds', 'box_bot_empty.world'), '']
  
  install_dir = get_package_prefix(package_name)

  if 'GAZEBO_MODEL_PATH' in os.environ:
    os.environ['GAZEBO_MODEL_PATH'] =  os.environ['GAZEBO_MODEL_PATH'] + ':' + install_dir + '/share'
  else:
    os.environ['GAZEBO_MODEL_PATH'] =  install_dir + "/share"


  if 'GAZEBO_PLUGIN_PATH' in os.environ:
    os.environ['GAZEBO_PLUGIN_PATH'] = os.environ['GAZEBO_PLUGIN_PATH'] + ':' + install_dir + '/lib'
  else:
    os.environ['GAZEBO_PLUGIN_PATH'] = install_dir + '/lib'
        
  #gazebo_models_path = os.path.join(pkg_share, gazebo_models_path)
  #os.environ["GAZEBO_MODEL_PATH"] = gazebo_models_path
  
  # Launch configuration variables specific to simulation
  gui = LaunchConfiguration('gui')
  headless = LaunchConfiguration('headless')
  namespace = LaunchConfiguration('namespace')
  rviz_config_file = LaunchConfiguration('rviz_config_file')
  #urdf_model = LaunchConfiguration('urdf_model')
  xacro_model = LaunchConfiguration('xacro_model')
  use_namespace = LaunchConfiguration('use_namespace')
  use_robot_state_pub = LaunchConfiguration('use_robot_state_pub')
  use_rviz = LaunchConfiguration('use_rviz')
  use_sim_time = LaunchConfiguration('use_sim_time')
  use_simulator = LaunchConfiguration('use_simulator')
  world = LaunchConfiguration('world')
  
  # Declare the launch arguments  
  declare_use_joint_state_publisher_cmd = DeclareLaunchArgument(
    name='gui',
    default_value='True',
    description='Flag to enable joint_state_publisher_gui')
    
  declare_namespace_cmd = DeclareLaunchArgument(
    name='namespace',
    default_value='',
    description='Top-level namespace')

  declare_use_namespace_cmd = DeclareLaunchArgument(
    name='use_namespace',
    default_value='false',
    description='Whether to apply a namespace to the navigation stack')
            
  declare_rviz_config_file_cmd = DeclareLaunchArgument(
    name='rviz_config_file',
    default_value=default_rviz_config_path,
    description='Full path to the RVIZ config file to use')

  declare_simulator_cmd = DeclareLaunchArgument(
    name='headless',
    default_value='False',
    description='Whether to execute gzclient')
  

  
  declare_xacro_model_path_cmd = DeclareLaunchArgument(
    name='xacro_model', 
    default_value=default_xacro_model_path, 
    description='Absolute path to robot xacro file')
  #declare_urdf_model_path_cmd = DeclareLaunchArgument(
    #name='urdf_model', 
    #default_value=default_urdf_model_path, 
    #description='Absolute path to robot urdf file')
    
  declare_use_robot_state_pub_cmd = DeclareLaunchArgument(
    name='use_robot_state_pub',
    default_value='True',
    description='Whether to start the robot state publisher')

  declare_use_rviz_cmd = DeclareLaunchArgument(
    name='use_rviz',
    default_value='True',
    description='Whether to start RVIZ')
    
  declare_use_sim_time_cmd = DeclareLaunchArgument(
    name='use_sim_time',
    default_value='true',
    description='Use simulation (Gazebo) clock if true')

  declare_use_simulator_cmd = DeclareLaunchArgument(
    name='use_simulator',
    default_value='True',
    description='Whether to start the simulator')

  declare_world_cmd = DeclareLaunchArgument(
    name='world',
    default_value=world_path,
    description='Full path to the world model file to load')
  
  # Subscribe to the joint states of the robot, and publish the 3D pose of each link.    
  #start_robot_state_publisher_cmd = Node(
    #package='robot_state_publisher',
    #executable='robot_state_publisher',
    #parameters=[{'robot_description': Command(['xacro ', urdf_model])}])
    
  robot_description_config = xacro.process_file(default_xacro_model_path)
  robot_desc = robot_description_config.toxml()
  # Subscribe to the joint states of the robot, and publish the 3D pose of each link.    
  start_robot_state_publisher_cmd = Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="robot_state_publisher",
            parameters=[
                {"robot_description": robot_desc}],
            output="screen")
  # Publish the joint states of the robot
  #start_joint_state_publisher_cmd = Node(
    #package='joint_state_publisher',
    #executable='joint_state_publisher',
    #name='joint_state_publisher',
    #condition=UnlessCondition(gui))
  start_joint_state_publisher_cmd = Node(
    package='joint_state_publisher_gui',
    executable='joint_state_publisher_gui',
    name='joint_state_publisher',
    )
  # Launch RViz
  start_rviz_cmd = Node(
    package='rviz2',
    executable='rviz2',
    name='rviz2',
    output='screen',
    arguments=['-d', rviz_config_file])

  # Start Gazebo server
  start_gazebo_server_cmd = IncludeLaunchDescription(
    PythonLaunchDescriptionSource(os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')),
    condition=IfCondition(use_simulator),
    launch_arguments={'world': world}.items())

  # Start Gazebo client    
  start_gazebo_client_cmd = IncludeLaunchDescription(
    PythonLaunchDescriptionSource(os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')),
    condition=IfCondition(PythonExpression([use_simulator, ' and not ', headless])))

  # Launch the robot
  spawn_entity_cmd = Node(
    package='gazebo_ros', 
    executable='spawn_entity.py',
    arguments=['-entity', robot_name_in_model, 
                #'-xml', robot_desc,
                '-topic', '/robot_description',
                    '-x', spawn_x_val,
                    '-y', spawn_y_val,
                    '-z', spawn_z_val,
                    '-R', spawn_roll_val,
                    '-P', spawn_pitch_val,
                    '-Y', spawn_yaw_val],
                    output='screen')

  # Create the launch description and populate
  ld = LaunchDescription()

  # Declare the launch options
  ld.add_action(declare_use_joint_state_publisher_cmd)
  #ld.add_action(declare_namespace_cmd)
  #ld.add_action(declare_use_namespace_cmd)
  ld.add_action(declare_rviz_config_file_cmd)
  ld.add_action(declare_simulator_cmd)
  ld.add_action(declare_xacro_model_path_cmd)
  #ld.add_action(declare_urdf_model_path_cmd)
  ld.add_action(declare_use_robot_state_pub_cmd)  
  ld.add_action(declare_use_rviz_cmd) 
  #ld.add_action(declare_use_sim_time_cmd)
  #ld.add_action(declare_use_simulator_cmd)
  #ld.add_action(declare_world_cmd)

  # Add any actions
  #ld.add_action(start_gazebo_server_cmd)
  #ld.add_action(start_gazebo_client_cmd)
  #ld.add_action(spawn_entity_cmd)
  ld.add_action(start_robot_state_publisher_cmd)
  ld.add_action(start_joint_state_publisher_cmd)
  ld.add_action(start_rviz_cmd)

  return ld
